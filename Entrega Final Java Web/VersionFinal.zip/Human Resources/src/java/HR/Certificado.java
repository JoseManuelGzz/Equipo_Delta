/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HR;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Faintinger
 */
public class Certificado {
    private String IdCandidato;
    private String Nombre;
    private String Certificadora;
    private String Year;
    private String Nivel;
    
    public Certificado(String Id, String N, String Cer, String Y, String Nvl)
    {
        IdCandidato = Id;
        Nombre = N;
        Certificadora = Cer;
        Year = Y;
        Nivel = Nvl;
    }
    
    public String getIdC()
    {
        return IdCandidato;
    }
    
    public String getYear()
    {
        return Year;
    }
    
    public String getNombre()
    {
        return Nombre;
    }
    
    public String getCertificadora()
    {
        return Certificadora;
    }
    
    public String getNivel()
    {
        return Nivel;
    }
    
    public void guardarCertificado() 
    {
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try{
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password);
            Statement st = conn.createStatement(); 
            st.execute("Insert into certificado (IdCandidato, Titulo, Certificadora, Year, Nivel) values ('" +
                this.IdCandidato + "','" + this.Nombre + "','" + this.Certificadora +
                "','" + this.Year + "','" + this.Nivel + "')");   
            st.close();
            conn.close();
        } catch(Exception ex) {
            
        }
    }
    public void modificaCertificado(String sIdCandidato) 
    {
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try{
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password);
            Statement st = conn.createStatement(); 
            st.execute("UPDATE certificado SET Titulo='" +
                this.Nombre + "' ,Certificadora='" + this.Certificadora +
                "' ,Year='" + this.Year + "' ,Nivel='" + this.Nivel + "' WHERE IdCandidato='" + sIdCandidato+"'");
            st.close();
            conn.close();
        } catch(Exception ex) {
            
        }
    }
}

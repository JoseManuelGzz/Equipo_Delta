/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HR;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.*;
import java.util.ArrayList;


/**
 *
 * @author Faintinger
 */
public class Empleado {
    private String Id;
    private String IdCandidato;
    private String PuestoActual;
    private int SalarioActual;
    private String Fecha;
    private Area Area;
    private ArrayList <Vacaciones> Vacaciones = new ArrayList<Vacaciones>();
    
    
    public Empleado()
    {
        Id = "";
        IdCandidato = "";
        PuestoActual = "";
        SalarioActual = 0;
        Fecha = "";
        Area = new Area();
        Vacaciones = new ArrayList <Vacaciones>();
    }
    
    public Empleado(String I, String IC, String PA, int SA, String F, Area A) {
        Id = I;
        IdCandidato = IC;
        PuestoActual = PA;
        SalarioActual = SA;
        Fecha = F;
        Area = A;
        Vacaciones = new ArrayList <Vacaciones>();
    }
    
    public void setId(String I)
    {
        Id = I;
    }
    
    public void setIdCandidato(String IC)
    {
        IdCandidato = IC;
    }
    
    public void setPuestoActal(String PA)
    {
        PuestoActual = PA;
    }
    
    public void setSalarioActual(int SA)
    {
        SalarioActual = SA;
    }
    
    public void setFecha(String F)
    {
        Fecha = F;
    }
    
    public void setArea(Area A)
    {
        Area = A;
    }
    
    public void addDiaLibre(Vacaciones V)
    {
        Vacaciones.add(V);
    }
    
    public String getId()
    {
        return Id;
    }
    
    public String getIdCandidato()
    {
        return IdCandidato;
    }
    
    public String getPuestoActual()
    {
        return PuestoActual;
    }
    
    public int getSalarioActual()
    {
        return SalarioActual;
    }
    
    public String getFechaInicio()
    {
        return Fecha;
    }
    
    public Area getArea()
    {
        return Area;
    }
    
    public ArrayList getVacacions()
    {
        return Vacaciones;
    }
    
    public Empleado getEmpleado(String idAux)
    {
        Empleado emp = new Empleado();
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try { 
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
            Statement st = conn.createStatement(); 
            ResultSet res = st.executeQuery("Select * From candidato Where Id='" + idAux + "';");
            emp.Id = res.getString("Id");
            emp.IdCandidato = res.getString("IdAceptacion");
            emp.PuestoActual = res.getString("PuestoActual");
            emp.SalarioActual = res.getInt("SalarioActual");
            emp.Fecha = res.getString("FechaInicio");
            String A = res.getString("Area");
            res = st.executeQuery("Select * From vacaciones Where ='" + idAux + "';");
            while(res.next()) {
                Vacaciones vAux = new Vacaciones(res.getString("IdEmpleado"),
                res.getString("fecha"), res.getBoolean("Utilizado"),
                res.getString("Motivo"));
                emp.addDiaLibre(vAux);
            }
            conn.close();
        } catch(Exception ex) {
            
        }
        return emp;
    }
    public void guardaEmpleado(String idAux)
    {
        Empleado emp = new Empleado();
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try { 
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
            Statement st = conn.createStatement(); 
            st.execute("INSERT INTO empleado (Id, IdAceptacion, PuestoActual, SalarioActual, FechaInicio) VALUES ('" + this.Id + "','"
            + idAux + "','" + this.PuestoActual + "','" + this.SalarioActual + "','"
            + this.Fecha + "')");
            st.close();
            st =conn.createStatement();
            st.execute("INSERT INTO area (Nombre, Supervisor) VALUES ('" + this.Area.getNombre() 
                    + "','" + this.Area.getIdCoordinador() + "')");
            /*for(int i = 0; i < this.Vacaciones.size(); i++) {
                this.Vacaciones.get(i).guardarVacaciones();
            }*/
            st.close();
            conn.close();
        } catch(Exception ex) {
            ex.toString();
        }
    }
    
    public String getIdEmpleado(String sNombreEmp, String sEmailEmp)
    {
        Empleado Aux = new Empleado();
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try { 
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
            Statement st = conn.createStatement(); 
            ResultSet res = st.executeQuery("Select Id From candidato Where Nombre='" + sNombreEmp + "' AND Email='" + sEmailEmp + "';"); 
            String sIdCandidato = res.getString("Id"); 
            res = st.executeQuery("SELECT Id FROM empleado WHERE IdAceptacion='" + sIdCandidato + "';");
            Aux.Id = res.getString("Id");
            st.close();
            conn.close(); 
        }
        
         catch (Exception e) { 
            e.printStackTrace(); 
        } 
        return Aux.Id;
    }
    
    public void modificaEmpleado(String sIdEmpleado, String idAux)
    {
        Empleado emp = new Empleado();
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try { 
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
            Statement st = conn.createStatement(); 
            st.execute("UPDATE empleado SET IdAceptacion='" +
            idAux + "' ,PuestoActual='" + this.PuestoActual + "' ,SalarioActual='" + this.SalarioActual + "' ,FechaInicio='"
            + this.Fecha + " WHERE Id=" + sIdEmpleado);
            st.execute("UPDATE area SET Nombre='" +
            this.Area.getNombre() + "' ,Supervisor='" + this.Area.getIdCoordinador() + "' WHERE Id='" + sIdEmpleado +"'");
            for(int i = 0; i < this.Vacaciones.size(); i++) {
                this.Vacaciones.get(i).modificarVacaciones(sIdEmpleado);
            }
            st.close();
            conn.close();
        } catch(Exception ex) {
            
        }
    }
    
    public void borraEmpleado(String idAux)
    {
        Empleado emp = new Empleado();
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try { 
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
            Statement st = conn.createStatement(); 
            st.execute("DELETE FROM empleado WHERE Id ='" + idAux + "'");
            st.close();
            conn.close();
        } catch(Exception ex) {
            
        }
    }
}

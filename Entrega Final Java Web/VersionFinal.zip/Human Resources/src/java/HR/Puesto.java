/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HR;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Faintinger
 */
public class Puesto {
    private String Id;
    private String Nombre;
    private Area area;
    private int Salario;
    
    Puesto(String i, String N, Area A, int S)
    {
        Id = i;
        Nombre = N;
        area = A;
        Salario = S;
    }
    
    public String getId()
    {
        return Id;
    }
    
    public String getNombre()
    {
        return Nombre;
    }
    
    public Area getArea()
    {
        return area;
    }
    
    public int getSalario()
    {
        return Salario;
    }
    
    public void guardaPuesto() 
    {
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try{
            Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
            Statement st = conn.createStatement(); 
            ResultSet res = st.executeQuery("Insert into puesto values (" +
                this.Id + "," + this.Nombre + "," + this.area +
                "," + this.Salario + ")");   
            conn.close();
        } catch(Exception ex) {
            
        }
    }
}

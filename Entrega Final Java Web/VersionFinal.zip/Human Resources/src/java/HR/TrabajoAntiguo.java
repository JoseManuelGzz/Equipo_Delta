/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HR;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Faintinger
 */
public class TrabajoAntiguo {
    String IdCandidato;
    String Nombre;
    String Puesto;
    String FechaInicio;
    String FechaFin;
    String Company;
    int Salario;
    String Descripcion;
    
    public TrabajoAntiguo(String Id, String N, String P, String FI, String FF, String C, int S, String D)
    {
        IdCandidato = Id;
        Nombre = N;
        Puesto = P;
        FechaInicio = FI;
        FechaFin = FF;
        Company = C;
        Salario = S;
        Descripcion = D;
    }
    
    public TrabajoAntiguo(String Id)
    {
        IdCandidato = Id;
    }
    
    public void setNombre( String N)
    {
        Nombre = N;
    }
    
    public void setPuesto(String P)
    {
        Puesto = P;
    }
    
    public void setFechaInicio(String F)
    {
        FechaInicio = F;
    }
    
    public void setFechaFin(String F)
    {
        FechaFin = F;
    }
    
    public void setCompany(String C)
    {
        Company = C;
    }
    
    public void setSalario(int S)
    {
        Salario = S;
    }
    
    public void setDescripcion(String D)
    {
        Descripcion = D;
    }
    
    public String getId()
    {
        return IdCandidato;
    }
    
    public String getNombre()
    {
        return Nombre;
    }
    
    public String getPuesto()
    {
        return Puesto;
    }
    
    public String getFechaInicio()
    {
        return FechaInicio;
    }
    
    public String getFechaFin()
    {
        return FechaFin;
    }
    
    public String getCompany()
    {
        return Company;
    }
    
    public String getDescripcion()
    {
        return Descripcion;
    }
    
    public int getSalario()
    {
        return Salario;
    }
    
    public void guardarTrabajoAntiguo() 
    {
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try{
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password);
            Statement st = conn.createStatement(); 
            st.execute("Insert into trabajosantiguos (IdCandidato, Nombre, Puesto, FechaInicio, FechaFin, Salario, Compania, Descripcion) values ('" + 
                this.IdCandidato + "," + this.Nombre +"," + this.Puesto +
                    "','" + this.FechaInicio + "','" + this.FechaFin +"','" + 
                    Integer.toString(this.Salario) + "','" + 
                    this.Company + "','" + this.Descripcion +"')");
            st.close();
            conn.close();
        } catch(Exception ex) {
            
        }
    }
    
    public void modificaTrabajoAntiguo(String sIdCandidato) 
    {
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try{
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password);
            Statement st = conn.createStatement(); 
            st.execute("UPDATE trabajosantiguos SET Nombre='" + 
                this.Nombre + "' ,Puesto='" + this.Puesto +
                    "' ,FechaInicio='" + this.FechaInicio + "' ,FechaFin='" + this.FechaFin +"' ,Salario='" + 
                    Integer.toString(this.Salario) + "' ,Compania='" + 
                    this.Company + "' ,Descripcion='" + this.Descripcion + "' WHERE IdCandidato='" + sIdCandidato+"'");
            st.close();
            conn.close();
        } catch(Exception ex) {
            
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HR;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
/**
 *
 * @author Jose Manuel
 */
public class Administrador {
    private String IdAdministrador;
    private String Contrasena;
    
    public Administrador() {
        this.IdAdministrador = "";
        this.Contrasena = "";
    }
    public Administrador(String I, String C) {
        IdAdministrador = I;
        Contrasena = C;
    }
    public String getIdAdministrador() {
        return IdAdministrador;
    }
    
    public String getContrasena() {
        return Contrasena;
    }
    public void setIdAdministrador(String I) {
        IdAdministrador = I;
    }
    public void setContrasena(String C) {
        Contrasena = C;
    }
    
    public void cerrarSesion(){
        
    }
    
    public boolean buscarAdministrador()
    {
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try {
            System.out.println(IdAdministrador + " 2 " + Contrasena);
            //Class.forName(driver).newInstance(); 
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
            Statement st = conn.createStatement(); 
            String query = "SELECT * FROM administrador WHERE id='"+IdAdministrador+"' AND password='"+Contrasena+"'";
            ResultSet res = st.executeQuery(query);
            
            if(res.next()){
                st.close();
                conn.close();
                return true;
            }
            
            
            
            st.close();
            conn.close();
            return false;
            
        } catch(Exception ex) {
            
        }
        return false;
    }
}

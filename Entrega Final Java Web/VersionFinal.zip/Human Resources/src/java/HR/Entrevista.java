/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HR;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Faintinger
 */
public class Entrevista {
    private String Id = "";
    private String IdEntrevistador = "";
    private String IdEntrevistado = "";
    private String Fecha = "";
    private String Plataforma = "";
    private int Duracion = 0;
    private String Comentarios = "";
    private int Calificacion = 0;
    
    public Entrevista() {
        Id = "";
        IdEntrevistador = "";
        IdEntrevistado = "";
        Fecha = "";
        Plataforma = "";
        Duracion = 0;
        Comentarios = "";
        Calificacion = 0;
    }
    
    public Entrevista(String I, String IER, String IEO, String F, String P, int D, 
                                                              String C, int Cal)
    {
        Id = I;
        IdEntrevistador = IER;
        IdEntrevistado = IEO;
        Fecha = F;
        Plataforma = P;
        Duracion = D;
        Comentarios = C;
        Calificacion = Cal;
    }
    
    public String getId()
    {
        return Id;
    }
    
    public String getIdEntrevistador()
    {
        return IdEntrevistador;
    }
    
    public String getIdEntrevistado()
    {
        return IdEntrevistado;
    }
    
    public String getFecha()
    {
        return Fecha;
    }
    
    public String getPlataforma()
    {
        return Plataforma;
    }
    
    public String getComentarios()
    {
        return Comentarios;
    }
    
    public int getDuracion()
    {
        return Duracion;
    }
    
    public int getCalificacion()
    {
        return Calificacion;
    }
    public Entrevista getEntrevista(String IDE)
    {
        Entrevista Aux = new Entrevista();
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try { 
            Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
            Statement st = conn.createStatement(); 
            ResultSet res = st.executeQuery("Select * From empleado Where Id='" + IDE + "';"); 
            
            Aux.Id = res.getString("Id");
            Aux.IdEntrevistador = res.getString("Entrevistador");
            Aux.IdEntrevistado = res.getString("Entrevistado");
            Aux.Fecha = res.getString("Fecha");
            Aux.Plataforma = res.getString("Plataforma");
            Aux.Duracion = res.getInt("Duracion");
            Aux.Calificacion = res.getInt("Calificacion");
            Aux.Comentarios = res.getString("Comentarios");
            st.close();    
            conn.close();   
        } catch (Exception e) { 
            e.printStackTrace(); 
        } 
        return Aux;
    }
    
    public String getIdEntrevista(String sNomCandidato, String sNomEmpleado)
    {
        Entrevista Aux = new Entrevista();
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try { 
            Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
            Statement st = conn.createStatement(); 
            ResultSet res = st.executeQuery("Select Id From candidato Where Nombre='" + sNomCandidato + "';"); 
            String sIdCandidato = res.getString("Id");
            res = st.executeQuery("Select Id From empleado Where IdAceptacion='" + sIdCandidato + "';");     
            String sIdEmpleado = res.getString("Id");
            res = st.executeQuery("Select Id From entrevista Where Entrevistador='" + sIdEmpleado + "' AND Entrevistado='" + sIdCandidato + "';"); 
            Aux.Id =res.getString("Id");
            st.close();
            conn.close();   
        } catch (Exception e) { 
            e.printStackTrace(); 
        } 
        return Aux.Id;
    }
    
    public void guardaEntrevista()
    {
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try{
            Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
            Statement st = conn.createStatement(); 
            st.execute("Insert into entrevista values ('" + 
                this.Id + "','" + this.IdEntrevistador + "','" + this.IdEntrevistado + "','" +
                this.Fecha + "','" + this.Plataforma +"','" + Integer.toString(this.Duracion) + "','" + 
                Integer.toString(this.Calificacion) + "','" +
                this.Comentarios + "')");
            st.close();
            conn.close();
        } catch(Exception Ex) {
            
        }
    }
    public void borraEntrevista(String idAux)
    {
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try{
            Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
            Statement st = conn.createStatement(); 
            st.execute("DELETE FROM entrevista WHERE Id = '" + 
                idAux + "'");
            st.close();
            conn.close();
        } catch(Exception Ex) {
            
        }
    }
    public void modificaEntrevista(String sIdEntrevista)
    {
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try{
            Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
            Statement st = conn.createStatement(); 
            st.execute("UPDATE entrevista SET Entrevistador='" + 
                this.IdEntrevistador + "' ,Entrevistado='" + this.IdEntrevistado + "' ,Fecha='" +
                this.Fecha + "' ,Plataforma='" + this.Plataforma +"' ,Duracion='" + Integer.toString(this.Duracion) + "' ,Calificacion='" + 
                Integer.toString(this.Calificacion) + "' ,Comentarios='" +
                this.Comentarios + "' WHERE Id='" + sIdEntrevista +"'");
            st.close();
            conn.close();
        } catch(Exception Ex) {
            
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import HR.Area;
import HR.Candidato;
import HR.Empleado;
import HR.Vacaciones;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Jose Manuel
 */
@WebServlet(name = "modificarEmpleadoController", urlPatterns = {"/modificarEmpleadoController"})
public class modificarEmpleadoController extends HttpServlet {

    protected void doPost(HttpServletRequest request, 
                          HttpServletResponse response) 
                          throws ServletException, IOException {
        
         ServletContext context = getServletContext();
        
        String sIdCandidato = request.getParameter("idCandidato");
        String sIdEmpleado = request.getParameter("idEmpleado");
        String sFechaInicio = request.getParameter("fechaInicio");
        String sPuesto = request.getParameter("puesto");
        int iSalario = Integer.parseInt(request.getParameter("salario"));
        String sArea = request.getParameter("area");
        String sIDSupervisor = request.getParameter("supervisor");
       
        Area area = new Area(sArea, sIDSupervisor); 
        Empleado empleado = new Empleado(sIdEmpleado, sIdCandidato, 
                sPuesto, iSalario, sFechaInicio, area);
        //Codigo para modificar a un candidato
        Candidato candidato = new Candidato();
        candidato.setId(sIdCandidato);
        
        Candidato candidatoAux = new Candidato();
        candidatoAux = candidato.getCandidato(sIdCandidato);
        
        candidato.modificaCandidato(sIdCandidato);
        //vacaciones.modificarVacaciones(sIdEmpleado);
        empleado.modificaEmpleado(sIdEmpleado, sIdCandidato);
        
        // store the User object in the request object
        request.setAttribute("Empleado", empleado);
        // forward request and response objects to JSP page
        String url = "/modificarEmpleado.jsp";
        
        RequestDispatcher dispatcher =
            getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);  
        
    }
}

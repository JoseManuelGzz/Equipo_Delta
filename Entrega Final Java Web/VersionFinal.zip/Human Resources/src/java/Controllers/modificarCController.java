/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import HR.Candidato;
import java.lang.Object;

/**
 *
 * @author Faintinger
 */
@WebServlet(name = "modificarCController", urlPatterns = {"/modificarCController"})
public class modificarCController extends HttpServlet {
    protected void doGet(HttpServletRequest request, 
                          HttpServletResponse response) 
                          throws ServletException, IOException {
        // get a relative file name
        ServletContext context = getServletContext();
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = "";
        ArrayList <String> Id = new ArrayList<String>();
        try{
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
            Statement st = conn.createStatement(); 
            ResultSet res = st.executeQuery("Select Id From candidato");
            while(res.next()) {
                Id.add(res.getString(1));
            }
        } 
        catch(Exception error){
            
        }
        Candidato cant = new Candidato();
        String texto = "";
        for(int i = 0; i < Id.size(); i++)
        {
            Candidato aux = new Candidato();
            cant = aux.getCandidato(Id.get(i));
            texto += "<tr><td></td>" +
                    "<td>" + cant.getNombre() + "</td>" +
                    "<td>" + cant.getEmail() +"</td>" +
                    "<td>"+"<a href='modificarCandidato.jsp?id='"+ cant.getId() +">Modificar</a>"+
                    "</tr>";
        }
        // store the User object in the request object
        request.setAttribute("Cand", texto);
        // forward request and response objects to JSP page
        String url2 = "/modificarC.jsp";
        
        RequestDispatcher dispatcher =
            getServletContext().getRequestDispatcher(url2);
        dispatcher.forward(request, response);   
    }
}

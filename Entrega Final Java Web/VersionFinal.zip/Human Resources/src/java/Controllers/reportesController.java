/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author LeonardoGutierrez
 */
@WebServlet(name = "reportesController", urlPatterns = {"/reportesController"})
public class reportesController extends HttpServlet {

    protected void doPost(HttpServletRequest request, 
                          HttpServletResponse response) 
                          throws ServletException, IOException {
        
        response.setContentType("text/plain");
        String filtro = request.getParameter("filtro");
        String text = request.getParameter("text");
        String orderBy="";
        switch(filtro){
            case "1":{
                orderBy = "Titulo";
                break;
            }
            case "2":{
                orderBy = "Universidad";
                break;
            }
            case "3":{
                orderBy = "idCandidato";
                break;
            }
            case "4":{
                orderBy = "idEmpleado";
                break;
            }
            case "5":{
                orderBy = "certificado";
                break;
            }
            case "6":{
                orderBy = "Entrevistador";
                break;
            }
            case "7":{
                orderBy = "PuestoActual";
                break;
            }
            default:{
                orderBy = "idCandidato";
                break;
            }
        }
        
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
            Statement st = conn.createStatement(); 
            String query = "SELECT candidato.Id as idCandidato, empleado.Id as idEmpleado, candidato.Nombre, titulo.Titulo, titulo.Universidad, certificado.Titulo as certificado ,entrevista.Entrevistador, empleado.PuestoActual FROM candidato LEFT JOIN entrevista ON candidato.Id = entrevista.Id LEFT JOIN titulo ON titulo.idCandidato = candidato.Id LEFT JOIN empleado ON empleado.IdAceptacion=candidato.Id LEFT JOIN certificado ON certificado.IdCandidato=candidato.Id ORDER BY "+orderBy+";";
            ResultSet res = st.executeQuery(query);
            String retorno="<div class=\"container\"><table class=\"table table-hover\"><tr><th>idCandidato</th><th>idEmpleado</th><th>Nombre</th><th>Titulo</th><th>Universidad</th><th>Certificado</th><th>Entrevistador</th><th>Puesto</th></tr>";
            
            while(res.next()){
                retorno+="<tr><td>"+res.getString("idCandidato")+"</td><td>"+res.getString("idEmpleado")+"</td><td>"+res.getString("Nombre")+"</td><td>"+res.getString("Titulo")+"</td><td>"+res.getString("Universidad")+"</td><td>"+res.getString("certificado")+"</td><td>"+res.getString("Entrevistador")+"</td><td>"+res.getString("PuestoActual")+"</td></tr>";
            
            }
            retorno+="</table></div>";
            System.out.println(retorno);
            PrintWriter out = response.getWriter();
            out.println(retorno);
            request.setAttribute(retorno, out);
        } catch(ClassNotFoundException | SQLException | IOException ex) {
            
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import HR.Candidato;
import HR.Certificado;
import HR.Tecnologias;
import HR.Titulo;
import HR.TrabajoAntiguo;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import HR.Administrador;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Jose Manuel
 */
@WebServlet(name = "loginController", urlPatterns = {"/loginController"})
public class loginController extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // get a relative file name
        ServletContext context = getServletContext();
        Administrador admin = new Administrador();
        boolean bExiste = false;
        String sNombre = request.getParameter("username");
        String sPassword = request.getParameter("password");
        
        System.out.println(sNombre + " " + sPassword);
        
        admin.setIdAdministrador(sNombre);
        admin.setContrasena(sPassword);
        
        bExiste = admin.buscarAdministrador();
        
        // store the User object in the request object
        //request.setAttribute("Administrador", admin);
        // forward request and response objects to JSP page
        String url = "";    
        
        if(bExiste) {
            // forward request and response objects to JSP page
            System.out.println("bExiste");
            HttpSession session = request.getSession(true);
            session.setAttribute("login", "true");
         url = "/index.jsp";
        }
        else {
            // forward request and response objects to JSP page
            System.out.println("bNoExiste");
            HttpSession session = request.getSession(true);
            session.setAttribute("login", "false");
         url = "/login.jsp";
        }
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response); 
    }
}

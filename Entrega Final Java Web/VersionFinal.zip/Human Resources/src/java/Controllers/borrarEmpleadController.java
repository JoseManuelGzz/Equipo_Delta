/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import HR.Empleado;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Jose Manuel
 */
@WebServlet(name = "borrarEmpleadController", urlPatterns = {"/borrarEmpleadController"})
public class borrarEmpleadController extends HttpServlet {

    protected void doPost(HttpServletRequest request, 
                          HttpServletResponse response) 
                          throws ServletException, IOException {
        // get a relative file name
        ServletContext context = getServletContext();
        
        String sId = request.getParameter("idEmpleado"); // Este es el Nombre que se tiene que recibir al dar click en el boton Eliminar
        Empleado empleado = new Empleado();
        empleado.borraEmpleado(sId);
        
        
        // forward request and response objects to JSP page
        String url = "/eliminarE.jsp";
        
        RequestDispatcher dispatcher =
            getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);    
    }
}

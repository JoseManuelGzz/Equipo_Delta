/*------------------------ Agregas estado a la form --------------------------------------- */

function addEstados() {
	var x = document.getElementById("estado");
	var option = document.createElement("option");
	var estados =["Aguascalientes","Baja California","Baja California Sur","Campeche","Chiapas",
	"Chihuahua","Coahuila","Colima","Distrito Federal","Durango","Estado de México","Guanajuato",
	"Guerrero","Hidalgo","Jalisco","Michoacán","Morelos","Nayarit","Nuevo León","Oaxaca","Puebla",
	"Querétaro","Quintana Roo","San Luis Potosí","Sinaloa","Sonora","Tabasco","Tamaulipas",
	"Tlaxcala","Veracruz","Yucatán","Zacatecas"];
	
		for(i=0;i<=31;i++){
			var option = document.createElement("option");
			option.text = estados[i];
			option.value = estados[i];
			x.add(option, x[i]);
		}
	};
	
	function getIndex() {
	    document.getElementById("demo").innerHTML = document.getElementById("estado").value;
	};

/*------------------------ Agregas otro titulo --------------------------------------- */

$(document).ready(function(){
    var counter = 2;
    $("#addTitulo").click(function () {
	if(counter>10){
            alert("Only 10 textboxes allow");
            return false;
	}   
	var newTextBoxDiv = $(document.createElement('div')).attr("id", 'TextBoxDivTitulo' + counter);
    newTextBoxDiv.after().html('<div class="col-md-4"><br> <div class="form-group"> <p>Universidad</p> <input type="text" name="universidad" class="form-control"> </div> <div class="form-group"> <p>Título</p> <input type="text" name="titulo" class="form-control"> </div> <div class="form-group"> <p>Año de obtención</p> <input type="month" name="yearobt" class="form-control"> </div> <br> </div> <div class="col-md-1"></div> <div class="col-md-4"> <div class="form-group"> <br><br> <p>Nivel</p> <select class="form-control" name="nivel"> <option>Profesional</option> <option>Posgrado</option> <option>Maestría</option> <option>Doctorado</option> </select> </div> <div class="form-group"> <p>Calificación</p> <input type="number" name="calificación" min="0" max="100" class="form-control"> </div> </div> <div class="col-md-12"></div>');            
	newTextBoxDiv.appendTo("#TextBoxesGroupTitulo");
	counter++;
     });

     $("#removeTitulo").click(function () {
	if(counter==2){
          alert("No hay más títulos que quitar");
          return false;
       }   
	counter--;
        $("#TextBoxDivTitulo" + counter).remove();
			
     });
     $("#getButtonValue").click(function () {
	var msg = '';
	for(i=1; i<counter; i++){
   	  msg += "\n Textbox #" + i + " : " + $('#textbox' + i).val();
	}
    	  alert(msg);
     });
  });

/*------------------------ Agregas otro titulo --------------------------------------- */
$(document).ready(function(){
    var counter = 2;
    $("#addCertificado").click(function () {
	if(counter>10){
            alert("Only 10 textboxes allow");
            return false;
	}   
	var newTextBoxDiv = $(document.createElement('div')).attr("id", 'TextBoxDivCertificado' + counter);
    newTextBoxDiv.after().html('<div class="col-md-4"><br><div class="form-group"><p>Título</p><input type="text" name="CertTitulo" class="form-control"></div><div class="form-group"><p>Certificadora</p><input type="text" name="certificadora" class="form-control"></div></div><div class="col-md-1"></div><div class="col-md-4"><br><div class="form-group"><p>Año de obtención</p><input type="month" name="yearCert" class="form-control"></div><div class="form-group"><p>Nivel</p><input type="text" name="nivelCert" class="form-control"></div></div>');            
	newTextBoxDiv.appendTo("#TextBoxesGroupCertificado");
	counter++;
     });

     $("#removeCertificado").click(function () {
	if(counter==2){
          alert("No hay más certificados que quitar");
          return false;
       }   
	counter--;
        $("#TextBoxDivCertificado" + counter).remove();
			
     });
     $("#getButtonValue").click(function () {
	var msg = '';
	for(i=1; i<counter; i++){
   	  msg += "\n Textbox #" + i + " : " + $('#textbox' + i).val();
	}
    	  alert(msg);
     });
  });
/*------------------------ Agregas otra herramienta --------------------------------------- */
$(document).ready(function(){
    var counter = 2;
    $("#addHerramienta").click(function () {
	if(counter>10){
            alert("Only 10 textboxes allow");
            return false;
	}   
	var newTextBoxDiv = $(document.createElement('div')).attr("id", 'TextBoxDivTecno' + counter);
    newTextBoxDiv.after().html('<div class="form-group"><p>Herramientas/tecnológias</p><input type="text" name="tecnologias" class="form-control"></div>');            
	newTextBoxDiv.appendTo("#addTecnologias");
	counter++;
     });

     $("#removeHerramienta").click(function () {
	if(counter==2){
          alert("No hay más que quitar");
          return false;
       }   
	counter--;
        $("#TextBoxDivTecno" + counter).remove();
			
     });
     $("#getButtonValue").click(function () {
	var msg = '';
	for(i=1; i<counter; i++){
   	  msg += "\n Textbox #" + i + " : " + $('#textbox' + i).val();
	}
    	  alert(msg);
     });
  });

/*------------------------ Agregas otro Hobby --------------------------------------- */
$(document).ready(function(){
    var counter = 2;
    $("#addHobby").click(function () {
	if(counter>10){
            alert("Only 10 textboxes allow");
            return false;
	}   
	var newTextBoxDiv = $(document.createElement('div')).attr("id", 'TextBoxDivHobby' + counter);
    newTextBoxDiv.after().html('<div class="form-group"><p>Hobby</p><input type="text" name="hobby" class="form-control"></div>');            
	newTextBoxDiv.appendTo("#addHobbies");
	counter++;
     });

     $("#removeHobby").click(function () {
	if(counter==2){
          alert("No hay más que quitar");
          return false;
       }   
	counter--;
        $("#TextBoxDivHobby" + counter).remove();
			
     });
     $("#getButtonValue").click(function () {
	var msg = '';
	for(i=1; i<counter; i++){
   	  msg += "\n Textbox #" + i + " : " + $('#textbox' + i).val();
	}
    	  alert(msg);
     });
  });
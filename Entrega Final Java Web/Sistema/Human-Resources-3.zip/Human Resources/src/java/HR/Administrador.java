/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HR;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
/**
 *
 * @author Jose Manuel
 */
public class Administrador {
    private String IdAdministrador;
    private String Nombre;
    private String Contrasena;
    
    public Administrador() {
        this.IdAdministrador = "";
        this.Nombre = "";
        this.Contrasena = "";
    }
    public Administrador(String I, String N, String C) {
        IdAdministrador = I;
        Nombre = N;
        Contrasena = C;
    }
    public String getIdAdministrador() {
        return IdAdministrador;
    }
    public String getNombre() {
        return Nombre;
    }
    public String getContrasena() {
        return Contrasena;
    }
    public void setIdAdministrador(String I) {
        IdAdministrador = I;
    }
    public void setNombre(String N) {
        Nombre = N;
    }
    public void setContrasena(String C) {
        Contrasena = C;
    }
    public boolean buscarAdministrador(String sNombre,String sPassword)
    {
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        boolean existe = false;
        try { 
            Administrador adminAux = new Administrador();
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
            Statement st = conn.createStatement(); 
            ResultSet res = st.executeQuery("Select Nombre,Password From Administrador Where Nombre='" + 
                    sNombre + " AND Password=" + sPassword + "';");
            adminAux.Nombre = res.getString("Nombre");
            adminAux.Contrasena = res.getString("Password");
            st.close();
            conn.close();
            if(adminAux.Nombre == sNombre && adminAux.Contrasena == sPassword) {
                existe = true;
            }
        } catch(Exception ex) {
            
        }
        return existe;
    }
}

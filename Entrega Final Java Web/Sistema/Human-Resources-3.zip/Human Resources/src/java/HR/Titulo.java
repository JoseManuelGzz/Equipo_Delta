/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HR;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Faintinger
 */
public class Titulo {
    private String IdCandidato;
    private String Nombre;
    private String Universidad;
    private String Year;
    private String Nivel;
    private int Calificacion;
    
    public Titulo(String Id, String N, String U, String Y, String Nvl, int C)
    {
        IdCandidato = Id;
        Nombre = N;
        Universidad = U;
        Year = Y;
        Nivel = Nvl;
        Calificacion = C;
    }
    
    public String getIdC()
    {
        return IdCandidato;
    }
    
    public String getYear()
    {
        return Year;
    }
    
    public String getNombre()
    {
        return Nombre;
    }
    
    public String getUniversidad()
    {
        return Universidad;
    }
    
    public String getNivel()
    {
        return Nivel;
    }
    
    public int getCalificacion()
    {
        return Calificacion;
    }
    
    public void guardarTitulo() 
    {
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try{
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password);
            Statement st = conn.createStatement(); 
            st.execute("Insert into titulo (IdCandidato, Titulo, Universidad, Year, Nivel, Calificacion) values ('" +
                this.IdCandidato + "','" + this.Nombre + "','" + this.Universidad +
                "','" + this.Year + "','" + this.Nivel + "','" + 
                Integer.toString(this.Calificacion) + "')");
            st.close();
            conn.close();
        } catch(Exception ex) {
            
        }
    }
    public void modificaTitulo(String sIdCandidato) 
    {
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try{
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
            Statement st = conn.createStatement(); 
            st.execute("UPDATE titulo SET Titulo='" +
                this.Nombre + "' ,Universidad='" + this.Universidad +
                "' ,Year='" + this.Year + "' ,Nivel='" + this.Nivel + "' ,Calificacion='" + 
                Integer.toString(this.Calificacion) + "' WHERE IdCandidato='" + sIdCandidato+"'");
            st.close();
            conn.close();
        } catch(Exception ex) {
            
        }
    }
}

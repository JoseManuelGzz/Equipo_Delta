/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HR;

import java.util.ArrayList;
import java.util.List;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Faintinger
 */
public class Candidato {
    private String Id;
    private String Nombre;
    private String Email;
    private String Telefono;
    private String salarioExpect;
    private String Calle;
    private String Ciudad;
    private String Estado;
    private String CP;
    private ArrayList <String> Hobbies = new ArrayList<String>();;
    private Tecnologias Tecnologias;
    private Titulo Titulos; 
    private Certificado Certificados;
    private TrabajoAntiguo AntTrabajos;
    
    public Candidato()
    {
        Id = "";
        Nombre = "";
        Email = "";
        Telefono = "";
        Calle = "";
        Ciudad = "";
        Estado = "";
        Hobbies = new ArrayList<String>();
        //Titulos = new Titulo();
        //AntTrabajos = new ArrayList();
        //Certificados = new ArrayList();
    }
    
    public Candidato(String ID, String N, String sEmail, String sTelefono, 
            String sCalle, String sCiudad, String sEstado)
    {
        Id = ID;
        Nombre = N;
        Email = sEmail;
        Telefono = sTelefono;
        Calle = sCalle;
        Ciudad = sCiudad;
        Estado = sEstado;
        Hobbies = new ArrayList<String>();
    }
    
    public void setId(String i)
    {
        Id = i;
    }
    
    public void setNombre(String n)
    {
        Nombre = n;
    }
    
    public void setEmail(String E)
    {
        Email = E;
    }
    
    public void setTelefono(String T)
    {
        Telefono = T;
    }
    
    public void setCalle(String C)
    {
        Calle = C;
    }
    
    public void setCiudad(String C)
    {
        Ciudad = C;
    }
    
    public void setEstado(String E)
    {
        Estado = E;
    }
   
    public void addTitulo(Titulo T)
    {
        Titulos = T;
    }
    
    public void addCertificado(Certificado C)
    {
        Certificados = C;
    }
    
    public void addTrabajoAnt(TrabajoAntiguo T)
    {
        AntTrabajos = T;
    }
    
    public void addTecnologia(Tecnologias T)
    {
        Tecnologias = T;
    }
    
    public void addHobbies(String H)
    {
        Hobbies.add(H);
    }
    
    public String getId()
    {
        return Id;
    }
    
    public String getNombre()
    {
        return Nombre;
    }
    
    public String getEmail()
    {
        return Email;
    }
    
    public String getCiudad()
    {
        return Ciudad;
    }
    
    public String getCalle()
    {
        return Calle;
    }
    
    public String getEstado()
    {
        return Estado;
    }
    
    public String getTelefono()
    {
        return Telefono;
    }
    
    public List getHobbies()
    {
        return Hobbies;
    }
    
    public Tecnologias getTecnologias()
    {
        return Tecnologias;
    }
    
    public Titulo getTitulos()
    {
        return Titulos;
    }
    
    public Certificado getCertificados()
    {
        return Certificados;
    }
    
    public TrabajoAntiguo getTrabajosAnt()
    {
        return AntTrabajos;
    }
    
    public Candidato getCandidato(String IDC)
    {
        Candidato Aux = new Candidato();
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try { 
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
            Statement st = conn.createStatement(); 
            ResultSet res = st.executeQuery("Select * From candidato Where Id='" + IDC + "';"); 
                Aux.Id = res.getString("Id"); 
                Aux.Nombre = res.getString("Nombre");
                Aux.Email = res.getString("Email");
                Aux.Telefono = res.getString("Telefono");
                Aux.Calle = res.getString("Calle");
                Aux.Ciudad = res.getString("Ciudad");
                Aux.Estado = res.getString("Estado");
            res = st.executeQuery("Select * From certificado Where IdCandidato ='"+ IDC +"';");
            while(res.next()) {
                Certificado C = new Certificado(res.getString("IdCandidato"),
                res.getString("Titulo"), res.getString("Certificadora"),
                res.getString("Year"), res.getString("Nivel"));
                Aux.addCertificado(C);
            }
            res = st.executeQuery("Select * From titulo Where IdCandidato = '" + IDC + "';");
            while(res.next()) {
                Titulo T = new Titulo(res.getString("IdCandidato"), 
                res.getString("Titulo"), res.getString("Universidad"),
                res.getString("Year"), res.getString("Nivel"),
                res.getInt("Calificacion"));
                Aux.addTitulo(T);
            }
            res = st.executeQuery("Select * From trabajosantiguos Where IdCandidato ='" + IDC + "';");
            while(res.next()) {
                TrabajoAntiguo AT = new TrabajoAntiguo(res.getString("IdCandidato"));
                AT.setNombre(res.getString("Nombre"));
                AT.setPuesto(res.getString("Puesto"));
                AT.setFechaInicio(res.getString("FechaInicio"));
                AT.setFechaFin(res.getString("FechaFin"));
                AT.setSalario(res.getInt("Salario"));
                AT.setCompany(res.getString("Compania"));
                AT.setDescripcion(res.getString("Descripcion"));
                Aux.addTrabajoAnt(AT);
            }
            res = st.executeQuery("Select * From tecnologias Where IdCandidato = '" + IDC + "';");
            while(res.next()) {
                Tecnologias Tec = new Tecnologias(res.getString("IdCandidato"), res.getString("Tecnologia"));
            }
            res = st.executeQuery("Select * From hobbies Where IdCandidato='" + IDC + "';");
            while(res.next()) {
                Aux.addHobbies(res.getString("Hobbie"));
        }
        conn.close(); 
        } catch (Exception e) { 
            e.printStackTrace(); 
        } 
        return Aux;
    }
    
    public String getIdCandidato(String sNombreCandidato, String sEmailCandidato)
    {
        Candidato Aux = new Candidato();
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try { 
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
            Statement st = conn.createStatement(); 
            ResultSet res = st.executeQuery("Select Id From candidato Where Nombre='" + sNombreCandidato + " AND Email=" + sEmailCandidato + "';"); 
            Aux.Id = res.getString("Id"); 
            
            conn.close(); 
        }
        
         catch (Exception e) { 
            e.printStackTrace(); 
        } 
        return Aux.Id;
    }
    
    public void guardarCandidato()
    {
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try{
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
            Statement st = conn.createStatement();
            st.execute("Insert into candidato(Id, Nombre, Email, Telefono, Calle, Ciudad, Estado) values ('" + 
                this.Id + "','" + this.Nombre + "','" + this.Email + "','" +
                this.Telefono +"','" + this.Calle + "','" + this.Ciudad + "','" +
                this.Estado + "')");
            st.close();
            for (int i = 0; i < Hobbies.size(); i++) {
                st = conn.createStatement();
                st.execute("Insert into hobbies(IdCandidato, Hobbie) values ('"
                        + this.Id + "','" + Hobbies.get(i) + "');");
                st.close();
            }
            //for(int i = 0; i < this.Tecnologias.size(); i++)
            //{
                /*st.executeUpdate("Insert into tecnologias values ("
                + this.Id + "," +  + ");");*/
            //}
            conn.close();
                this.Tecnologias.guardarTecnologias();
            //for(int i = 0; i < this.Certificados.size(); i++)
                this.Certificados.guardarCertificado();
            //for(int i = 0; i < this.AntTrabajos.size(); i++)
                this.AntTrabajos.guardarTrabajoAntiguo();
            //(int i = 0; i < this.Titulos.size(); i++)
                this.Titulos.guardarTitulo();
                System.out.println("todo");
            
        } catch(SQLException Ex) {
            System.out.println(Ex.toString());
        }
    }
    
    public void modificaCandidato(String sIdCandidato)
    {
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try{
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password);
            Statement st = conn.createStatement(); 
            
            st.execute("UPDATE candidato SET Nombre='" + 
                    this.Nombre + "' ,Email='" + this.Email + "',Telefono='" +
                    this.Telefono +"' ,Calle='" + this.Calle + "' ,Ciudad='" + this.Ciudad + "' ,Estado='" +
                    this.Estado + "' WHERE Id='" + sIdCandidato);
            st.close();
            for(int i = 0; i < this.Hobbies.size(); i++)
            {
                st = conn.createStatement();
                st.execute("UPDATE hobbies SET Hobbie='" +
                this.Hobbies.get(i) + "' WHERE IdCandidato='" + sIdCandidato + "'");
                st.close();
            }
            //for(int i = 0; i < this.Tecnologias.size(); i++)
            //{
                st = conn.createStatement();
                st.execute("UPDATE tecnologias SET tecnologia='" +
                this.Tecnologias + "' WHERE IdCandidato='" + sIdCandidato+"'");
                st.close();
            //}
            //for(int i = 0; i < this.Certificados.size(); i++) 
                this.Certificados.modificaCertificado(sIdCandidato);
            //for(int i = 0; i < this.AntTrabajos.size(); i++)
                this.AntTrabajos.modificaTrabajoAntiguo(sIdCandidato);
            //for(int i = 0; i < this.Titulos.size(); i++)
                this.Titulos.modificaTitulo(sIdCandidato);
            conn.close();

        } catch(Exception Ex) {
            
        }
    }
    
    public void borraCandidato(String idCandidato)
    {
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try{
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password);
            Statement st = conn.createStatement(); 
            st.execute("DELETE FROM candidato WHERE Id = '" + 
                idCandidato+"'");
            st.close();
            conn.close();
        } catch(Exception Ex) {
            
        }
    }
}

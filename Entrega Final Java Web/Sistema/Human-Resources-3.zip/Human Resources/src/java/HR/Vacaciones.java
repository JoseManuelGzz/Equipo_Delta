/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HR;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Faintinger
 */
public class Vacaciones {
    private String IdEmpleado;
    private String Fecha;
    private boolean Utilizado;
    private String Motivo;
    
    public Vacaciones() {
        IdEmpleado = "";
        Fecha = "";
        Utilizado = false;
        Motivo = "";
    }
    
    public Vacaciones(String iE, String F, Boolean U, String M)
    {
        IdEmpleado = iE;
        Fecha = F;
        Utilizado = U;
        Motivo = M;
    }
    
    public String getIdE()
    {
        return IdEmpleado;
    }
    
    public String getFecha()
    {
        return Fecha;
    }
    
    public String getMotivo()
    {
        return Motivo;
    }
    
    public boolean isUtilizado()
    {
        return Utilizado;
    }
    
    public void guardarVacaciones() 
    {
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try{
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password);
            Statement st = conn.createStatement(); 
            st.execute("INSERT INTO vacaciones (IdEmpleado, fecha, Utilizado, Motivo) VALUES ('" +
                this.IdEmpleado + "','" + this.Fecha + "','" + this.Utilizado +
                "','" + this.Motivo + "')");
            st.close();
            conn.close();
        } catch(Exception ex) {
            
        }
    }
    public void modificarVacaciones(String sIdEmpleado) 
    {
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try{
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password);
            Statement st = conn.createStatement(); 
            st.execute("UPDATE vacaciones fecha='" +
                this.Fecha + "' ,Utilizado='" + this.Utilizado +
                " ,Motivo='" + this.Motivo + "' WHERE IdEmpleado='" + sIdEmpleado+"'");
            st.close();
            conn.close();
        } catch(Exception ex) {
            
        }
    }
    
}

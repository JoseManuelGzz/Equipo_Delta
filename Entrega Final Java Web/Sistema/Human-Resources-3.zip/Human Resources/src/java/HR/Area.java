/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HR;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Faintinger
 */
public class Area {
    private String Id;
    private String Nombre;
    private String IdCoordinador;
    
    public Area()
    {
        Id = "";
        Nombre = "";
        IdCoordinador = "";
    }
    
    public Area(String I, String N, String IC) {
        Id = I;
        Nombre = N;
        IdCoordinador = IC;
    }
    
    public void setId(String i)
    {
        Id = i;
    }
    
    public void setNombre(String n)
    {
        Nombre = n;
    }
    
    public void setIdCoordinador(String iC)
    {
        IdCoordinador = iC;
    }
    
    public String getId()
    {
        return Id;
    }
    
    public String getNombre()
    {
        return Nombre;
    }
    
    public String getIdCoordinador()
    {
        return IdCoordinador;
    }
    
    public void guardaArea() 
    {
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try{
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
            Statement st = conn.createStatement(); 
            st.execute("Insert into area values (" +
                this.Id + "," + this.Nombre + "," + this.IdCoordinador + ")");
            st.close();
            conn.close();
        } catch(Exception ex) {
            
        }
    }
    
    public void buscarArea(String I)
    {
        String url = "jdbc:mysql://localhost:3306/"; 
        String dbName = "hr"; 
        String driver = "com.mysql.jdbc.Driver"; 
        String userName = "root"; 
        String password = ""; 
        try { 
            //Class.forName(driver).newInstance(); 
            Connection conn = DriverManager.getConnection(url+dbName,userName,password); 
            Statement st = conn.createStatement(); 
            ResultSet res = st.executeQuery("Select * From area Where Id='" + I + "';");
            this.Id = res.getString("Id");
            this.IdCoordinador = res.getString("Supervidor");
            this.Nombre = res.getString("Nombre");
            st.close();
            conn.close();
        } catch(Exception ex) {
            
        }
    }
}

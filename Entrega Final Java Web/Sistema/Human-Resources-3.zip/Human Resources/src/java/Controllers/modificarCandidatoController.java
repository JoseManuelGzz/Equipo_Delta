/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import HR.Candidato;
import HR.Certificado;
import HR.Tecnologias;
import HR.Titulo;
import HR.TrabajoAntiguo;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Jose Manuel
 */
@WebServlet(name = "modificarCandidatoController", urlPatterns = {"/modificarCandidatoController"})
public class modificarCandidatoController extends HttpServlet {

    protected void doPost(HttpServletRequest request, 
                          HttpServletResponse response) 
                          throws ServletException, IOException {
        int iId = 0; //Falta cambiar este ID por el que en teoria se recibe al dar clic.
        String sNombre = request.getParameter("nombre");
        String sEmail = request.getParameter("email");
        String sTelefono = request.getParameter("telefono");
        String sDireccion = "";
        String sCalle = request.getParameter("calle");
        String sCiudad = request.getParameter("ciudad");
        String sEstado = request.getParameter("estado");
        //Estudios universitarios
        String sUniversidad = request.getParameter("universidad");
        String sTitulo = request.getParameter("titulo");
        String sAnoObtencion = request.getParameter("yearobt");
        String sNivel = request.getParameter("nivel");
        int iCalificacion = Integer.parseInt(request.getParameter("calificacion"));
        //Certificacion
        String sCertificadoTitulo = request.getParameter("CertTitulo");
        String sCertificadora = request.getParameter("certificadora");
        String sAnoCertificacion = request.getParameter("yearCert");
        String sNivelCertificacion = request.getParameter("nivelCert");
        //Trabajo anterior
        String sNombreTrabajoAnterior = request.getParameter("nombreTrabajoAnterior");
        String sCompania = request.getParameter("compañia");
        String sPuesto = request.getParameter("puesto");
        int iSalario = Integer.parseInt(request.getParameter("salario"));
        String sFechaEntrada = request.getParameter("fechaEntrada");
        String sFechaSalida = request.getParameter("fechaSalida");
        String sDescripcion = request.getParameter("descripcionPuesto");
        //Tecnologias
        String sHerramienta = request.getParameter("tecnologias");
        String sHobbie = request.getParameter("Hobby");
        
        Candidato candidato = new Candidato(Integer.toString(iId), sNombre, sEmail, sTelefono,
                sCalle, sCiudad, sEstado);
        Titulo titulo = new Titulo(Integer.toString(iId), sTitulo, sUniversidad, sAnoObtencion, 
                sNivel, iCalificacion);
        Certificado certificado = new Certificado(Integer.toString(iId), sCertificadoTitulo,
                sCertificadora, sAnoCertificacion, sNivelCertificacion);
        TrabajoAntiguo trabajoAntiguo = new TrabajoAntiguo(Integer.toString(iId), sNombreTrabajoAnterior, 
                sPuesto, sFechaEntrada, sFechaSalida, sCompania, iSalario, sDescripcion);
        Tecnologias tecnologias = new Tecnologias(Integer.toString(iId), sHerramienta);
        
        candidato.addTitulo(titulo);
        candidato.addCertificado(certificado);
        candidato.addTrabajoAnt(trabajoAntiguo);
        candidato.addTrabajoAnt(trabajoAntiguo);
        candidato.addTecnologia(tecnologias);
        candidato.addHobbies(sHobbie);
        
        
        
        candidato.modificaCandidato(Integer.toString(iId));
        titulo.modificaTitulo(Integer.toString(iId));
        certificado.modificaCertificado(Integer.toString(iId));
        trabajoAntiguo.modificaTrabajoAntiguo(Integer.toString(iId));
        tecnologias.modificaTecnologias(Integer.toString(iId));
        
    }
}

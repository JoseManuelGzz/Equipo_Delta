/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import HR.Candidato;
import HR.Certificado;
import HR.Tecnologias;
import HR.Titulo;
import HR.TrabajoAntiguo;
import HR.Empleado;
import HR.Area;
import HR.Vacaciones;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Jose Manuel
 */
@WebServlet(name = "agregarEmpleadoController", urlPatterns = {"/agregarEmpleadoController"})
public class agregarEmpleadoController extends HttpServlet {

    protected void doPost(HttpServletRequest request, 
                          HttpServletResponse response) 
                          throws ServletException, IOException {
        
        // get a relative file name
        ServletContext context = getServletContext();
        
        String sIdCandidato = request.getParameter("idCandidato");
        String sIdEmpleado = request.getParameter("idEmpleado");
        String sFechaInicio = request.getParameter("fechaInicio");
        String sPuesto = request.getParameter("puesto");
        int iSalario = Integer.parseInt(request.getParameter("salario"));
        String sSupervisor = request.getParameter("supervisor");
        String sIDSupervisor = request.getParameter("idsupervisor");
       
        Area area = new Area(sIdEmpleado, sSupervisor, sIDSupervisor); 
        Empleado empleado = new Empleado(sIdEmpleado, sIdCandidato, 
                sPuesto, iSalario, sFechaInicio, area);
        Vacaciones vacaciones = new Vacaciones();
        empleado.addDiaLibre(vacaciones);
       
        //vacaciones.guardarVacaciones();
        empleado.guardaEmpleado(sIdCandidato);
        
        // store the User object in the request object
        request.setAttribute("Empleado", empleado);
        // forward request and response objects to JSP page
        String url = "/agregarEmpleado.jsp";
        
        RequestDispatcher dispatcher =
            getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);  
    }

}

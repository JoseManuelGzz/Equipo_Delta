/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import HR.Candidato;
import HR.Certificado;
import HR.Tecnologias;
import HR.Titulo;
import HR.TrabajoAntiguo;
import HR.Entrevista;
import HR.Empleado;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Jose Manuel
 */
@WebServlet(name = "agregarEntrevistaController", urlPatterns = {"/agregarEntrevistaController"})
public class agregarEntrevistaController extends HttpServlet {

   protected void doPost(HttpServletRequest request, 
                          HttpServletResponse response) 
                          throws ServletException, IOException {
        
        int iId = 0;                
        String sIdCandidato = request.getParameter("candidato");
        String sIdEmpleado = request.getParameter("empleado");
        String sFecha = request.getParameter("fecha");
        String sPlataforma = request.getParameter("plataforma");
        int iDuracion = Integer.parseInt(request.getParameter("duracion"));
        int iCalificacion = Integer.parseInt(request.getParameter("calificacion"));
        String sComentarios = request.getParameter("comentarios");
        
        Entrevista entrevista = new Entrevista(Integer.toString(iId), sIdEmpleado, sIdCandidato,
                sFecha, sPlataforma, iDuracion, sComentarios, iCalificacion);
        
        entrevista.guardaEntrevista();
    }
}
